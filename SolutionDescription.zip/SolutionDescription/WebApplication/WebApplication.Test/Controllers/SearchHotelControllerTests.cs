﻿using DataLayer.DataProvider;
using System;
using System.Collections.Generic;
using System.Text;
using WebApplication.Controllers;
using Xunit;


namespace WebApplication.Test.Controllers
{
    public class SearchHotelControllerTests
    {

        [Fact]
        public void Get_ThrowsException_WhenNullArgumentPassed()
        {
            SerchHotelController controller = new SerchHotelController(new MockHotelListDataProvider());
            Assert.Throws<ArgumentException>(() =>
            {
                controller.Get(null);
            });
        }

        [Fact]
        public void Get_ReturnsCorrectResult_WhenCorrectArgumentPassed()
        {
            SerchHotelController controller = new SerchHotelController(new MockHotelListDataProvider());
            var result = controller.Get("123123" );
            Assert.NotEmpty(result);
        }

    }
}
