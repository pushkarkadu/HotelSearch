﻿using DataLayer.DataProvider;
using DataLayer.Dto;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;

namespace WebApplication.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class SerchHotelController : ControllerBase
    {
        private readonly IHotelListDataProvider _hotelListDataProvider;

        public SerchHotelController(IHotelListDataProvider hotelListDataProvider)
        {
            _hotelListDataProvider = hotelListDataProvider;
        }
        [HttpGet]
        public IEnumerable<SearchHotelResultDto> Get(string locationId)
        {
            if (string.IsNullOrEmpty(locationId))
            {
                throw new ArgumentException();
            }
            return _hotelListDataProvider.SearchHotels(new SearchHotelRequestDto { LocationId = locationId });
        }

    }
}
