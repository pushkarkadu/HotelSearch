﻿using System;
using System.Linq;
using System.Threading.Tasks;

namespace DataLayer.Dto
{
    public class SearchHotelRequestDto
    {
        public string LocationId { get; set; }
    }
}
