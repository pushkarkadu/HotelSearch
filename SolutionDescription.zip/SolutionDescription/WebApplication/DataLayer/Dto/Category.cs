﻿namespace DataLayer.Dto
{
    public class Category
    {
        public string Name { get; set; }
        public string LocalizedName { get; set; }
    }
}
