﻿namespace DataLayer.Dto
{
    public class Subrating
    {
        public string RatingImageUrl { get; set; }
        public string Name { get; set; }
        public string Value { get; set; }
        public string LocalizedName { get; set; }
    }
}
