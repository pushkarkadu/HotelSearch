﻿namespace DataLayer.Dto
{
    public class Ancestor
    {
        public string Abbrv { get; set; }
        public string Level { get; set; }
        public string Name { get; set; }
        public string LocationId { get; set; }
    }
}
