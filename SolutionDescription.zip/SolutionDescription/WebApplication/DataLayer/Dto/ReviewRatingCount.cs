﻿namespace DataLayer.Dto
{
    public class ReviewRatingCount
    {
        public string _1 { get; set; }
        public string _2 { get; set; }
        public string _3 { get; set; }
        public string _4 { get; set; }
        public string _5 { get; set; }
    }
}
