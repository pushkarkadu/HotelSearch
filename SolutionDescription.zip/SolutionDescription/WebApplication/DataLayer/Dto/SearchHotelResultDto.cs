﻿using System.Collections.Generic;

namespace DataLayer.Dto
{
    public class SearchHotelResultDto
    {
        public AddressObj AddressObj { get; set; }
        public string Latitude { get; set; }
        public string Rating { get; set; }
        public string LocationId { get; set; }
        public List<TripType> TripTypes { get; set; }
        public string WriteReview { get; set; }
        public List<Ancestor> Ancestors { get; set; }
        public string Longitude { get; set; }
        public object Hours { get; set; }
        public object PercentRecommended { get; set; }
        public HotelBooking HotelBooking { get; set; }
        public ReviewRatingCount ReviewRatingCount { get; set; }
        public List<Subrating> Subratings { get; set; }
        public RankingData RankingData { get; set; }
        public string PhotoCount { get; set; }
        public string LocationString { get; set; }
        public string WebUrl { get; set; }
        public string PriceLevel { get; set; }
        public string RatingImageUrl { get; set; }
        public List<Award> Awards { get; set; }
        public string Name { get; set; }
        public string NumReviews { get; set; }
        public Category Category { get; set; }
        public List<Subcategory> Subcategory { get; set; }
        public string SeeAllPhotos { get; set; }
    }
}
