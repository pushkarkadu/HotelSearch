﻿namespace DataLayer.Dto
{
    public class HotelBooking
    {
        public bool Bookable { get; set; }
        public string BookingUrl { get; set; }
    }
}
