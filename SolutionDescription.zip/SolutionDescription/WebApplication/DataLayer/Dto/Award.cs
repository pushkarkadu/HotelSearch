﻿using System.Collections.Generic;

namespace DataLayer.Dto
{
    public class Award
    {
        public string AwardType { get; set; }
        public string Year { get; set; }
        public Images Images { get; set; }
        public List<object> Categories { get; set; }
        public string DisplayName { get; set; }
    }
}
