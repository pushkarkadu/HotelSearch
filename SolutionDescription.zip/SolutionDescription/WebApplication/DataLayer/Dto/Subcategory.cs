﻿namespace DataLayer.Dto
{
    public class Subcategory
    {
        public string Name { get; set; }
        public string LocalizedName { get; set; }
    }
}
