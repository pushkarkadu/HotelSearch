﻿namespace DataLayer.Dto
{
    public class Images
    {
        public string Small { get; set; }
        public string Large { get; set; }
    }
}
