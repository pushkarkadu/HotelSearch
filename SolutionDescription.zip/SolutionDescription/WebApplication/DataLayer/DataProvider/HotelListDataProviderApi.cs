﻿using DataLayer.Dto;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;

namespace DataLayer.DataProvider
{
    public class HotelListDataProviderApi : IHotelListDataProvider
    {
        public HotelListDataProviderApi()
        {

        }
        public IEnumerable<SearchHotelResultDto> SearchHotels(SearchHotelRequestDto requestDto)
        {
            string result = ExecuteRequest($"http://api.tripadvisor.com/api/partner/2.0/location/89575?key=<YOUR-KEY_HERE>");
            return JsonConvert.DeserializeObject<List<SearchHotelResultDto>>(result);
        }

        private string ExecuteRequest(string relativeUrl)
        {
            string result = null;
            HttpWebRequest request = CreateRequest(relativeUrl);
            var httpResponse = (HttpWebResponse)request.GetResponse();
            var encoding = System.Text.Encoding.GetEncoding(httpResponse.CharacterSet);
            using (BufferedStream buffer = new BufferedStream(httpResponse.GetResponseStream()))
            {
                using (var streamReader = new StreamReader(buffer, encoding))
                {
                    result = streamReader.ReadToEnd();
                }
            }

            return result;
        }

        private HttpWebRequest CreateRequest(string relativeUrl)
        {
            HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(relativeUrl);
            httpWebRequest.ContentType = "application/json";
            httpWebRequest.Accept = "application/json";
            httpWebRequest.Method = "GET";
            httpWebRequest.Proxy = null;

            return httpWebRequest;
        }

    }
}
