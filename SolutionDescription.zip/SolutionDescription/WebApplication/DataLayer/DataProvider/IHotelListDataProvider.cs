﻿using DataLayer.Dto;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.DataProvider
{
    public interface IHotelListDataProvider
    {
        IEnumerable<SearchHotelResultDto> SearchHotels(SearchHotelRequestDto requestDto);
    }
}
