import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HotelViewComponent } from './hotel-view/hotel-view.component';

const routes: Routes = [
  { path: 'viewHotels', component: HotelViewComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
