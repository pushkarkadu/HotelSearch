import { Component, OnInit, Input } from '@angular/core';
import { SearchHotelResultDto } from '../hotel-view.model';

@Component({
  selector: 'app-list-hotel',
  templateUrl: './list-hotel.component.html',
  styleUrls: ['./list-hotel.component.css']
})
export class ListHotelComponent implements OnInit {

  @Input()
  public hotels: SearchHotelResultDto[] = [];

  @Input()
  public refBenchMark: any;


  constructor() { }

  ngOnInit(): void {
  }

  public getColor(hotel: any): boolean {
    return +hotel?.rating > +this.refBenchMark;
  }
}
