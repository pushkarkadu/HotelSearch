import { Component, OnInit } from '@angular/core';
import { HotelViewService } from './hotel-view.service';
import { SearchHotelRequestDto, SearchHotelResultDto } from './hotel-view.model';

@Component({
  selector: 'app-hotel-view',
  templateUrl: './hotel-view.component.html',
  styleUrls: ['./hotel-view.component.css'],
  providers: [HotelViewService]
})
export class HotelViewComponent implements OnInit {

  public model: any = [];
  public hotels: any = null;
  constructor(private _hotelViewService: HotelViewService) {
    this.model.locationId = 123123;
    this.model.refBenchMark = 4;
  }

  ngOnInit(): void {
  }

  public cancel(): void {
    this.hotels = null;
  }
  save() {
    this._hotelViewService.searchHotels(this.model.locationId).subscribe(res => {
      this.hotels = res;
    });
  }

}
