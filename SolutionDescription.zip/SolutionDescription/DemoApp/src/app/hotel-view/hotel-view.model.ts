

export class SearchHotelRequestDto {
    public locationId: number | undefined;
}

export class SearchHotelResultDto {
    latitude: string | undefined;
    rating: string | undefined;
    locationId: string | undefined;
    longitude: string | undefined;
    photoCount: string | undefined;
    location_string: string | undefined;
    name: string | undefined;
    numReviews: string | undefined;

    constructor(data?: SearchHotelRequestDto) {
        if (data) {
            for (var property in data) {
                if (data.hasOwnProperty(property))
                    (<any>this)[property] = (<any>data)[property];
            }
        }
    }

    init(data?: any) {
        if (data) {
            this.latitude = data["latitude"];
            this.rating = data["rating"];
            this.locationId = data["locationId"];
            this.longitude = data["longitude"];
            this.photoCount = data["photoCount"];
            this.name = data["name"];
            this.numReviews = data["numReviews"];

        }
    }

    static fromJS(data: any): SearchHotelResultDto {
        data = typeof data === 'object' ? data : {};
        let result = new SearchHotelResultDto();
        result.init(data);
        return result;
    }
}