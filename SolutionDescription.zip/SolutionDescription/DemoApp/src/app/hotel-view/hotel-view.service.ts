import { SearchHotelRequestDto, SearchHotelResultDto } from './hotel-view.model';
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';


@Injectable()
export class HotelViewService {
    constructor(private http: HttpClient) { }
    httpOptions = {
        headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': 'http://localhost:4200',
            'Access-Control-Allow-Credentials': 'true'
        })
    };
    hostUrl = 'http://localhost:61416/SerchHotel';
    //StartProcessing
    searchHotels(requestDto: string): Observable<SearchHotelResultDto[]> {
        return this.http.get<SearchHotelResultDto[]>(this.hostUrl + '?locationId=' + requestDto, this.httpOptions);
    }
}